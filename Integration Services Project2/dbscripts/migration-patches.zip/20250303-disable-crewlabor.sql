delete from MAXIMO.AMCREW where STE_MIGRATIONID is not null;

delete from MAXIMO.AMCREWLABOR where STE_MIGRATIONID is not null;